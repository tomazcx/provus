<script setup lang="ts">
import Item from "@/components/BancoDeQuestoes/QuestionsBankItem/index.vue";
import type { IQuestao } from "~/types/IQuestao";
import formatDate from "~/utils/formatDate";

defineProps<{
  item: IQuestao;
}>();
</script>

<template>
  <Item :id="String(item.id)">
    <div
      class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center"
    >
      <Icon name="i-lucide-file-question" class="text-blue-600 text-lg" />
    </div>

    <div class="flex-1">
      <h3 class="font-medium text-gray-900">{{ item.titulo }}</h3>
      <p class="text-sm text-gray-600 mt-1">{{ item.descricao }}</p>

      <div class="flex items-center space-x-4 mt-2">
        <UBadge size="sm">{{ item.tipo }}</UBadge>
        <span class="text-xs text-gray-500"
          >Modificado {{ formatDate(item.atualizadoEm) }}</span
        >
      </div>
    </div>
  </Item>
</template>
